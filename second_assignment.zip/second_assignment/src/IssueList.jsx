import React, { Component } from 'react';
import './App.css';

class IssueList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      issues: [
        { id: 1, issue_description: 'On clicking Delete, the application crashes.', severity: 'Critical', status: 'Open' },
        { id: 2, issue_description: 'The heading Add is wrongly displayed as Edit.', severity: 'Minor', status: 'Closed' },
        { id: 3, issue_description: 'The Payment functionality is missing.', severity: 'Major', status: 'In Progress' },
      ],
    };
  }

  render() {
    return (
      <div className="issue-list-container">
        <h1>Issue List</h1>
        <table className="issue-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Issue Description</th>
              <th>Severity</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {this.state.issues.map((issue) => (
              <tr key={issue.id}>
                <td>{issue.id}</td>
                <td>{issue.issue_description}</td>
                <td>{issue.severity}</td>
                <td>{issue.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default IssueList;
